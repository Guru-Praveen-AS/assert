package com.codingspace.freecoin.model;

public enum NoticeType {
    NEWS, EVENTS, ACHIEVERS
}
